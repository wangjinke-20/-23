<template>
  <div>
      <h1>预处理器</h1>
      <div class='header'>

      </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="stylus" scoped>
.header
    width 100%
    heigth 100px
    border 1px solid  #ccc
</style>
